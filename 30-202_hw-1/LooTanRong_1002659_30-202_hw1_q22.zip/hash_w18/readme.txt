!!! --- 30.202 hw-1 q22 --- !!!

! - instructions - !
1. ensure that these files are in the same folder
    - main.py
    - binary_decimals_hex.py
    - hex_bitwise_operation.py
    - sha256_message_expander.py

2. run file "main.py" to obtain result for w18
