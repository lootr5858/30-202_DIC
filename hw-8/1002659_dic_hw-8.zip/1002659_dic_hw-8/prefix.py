""" -------- !! --------
             prefixes
     -------- !! -------- """
milli = 1e-3
micro = 1e-6
nano = 1e-9
pico = 1e-12
femto = 1e-15

giga = 1e9
